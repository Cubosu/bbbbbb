import mywindows3
import wx
import codes

class myframe1(my)