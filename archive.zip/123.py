import os

# print(os.listdir())

data=os.listdir()

for d in data:
	print(d)